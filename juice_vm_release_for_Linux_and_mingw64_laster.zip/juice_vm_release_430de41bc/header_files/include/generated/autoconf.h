/*
 *
 * Automatically generated file; DO NOT EDIT.
 * JuiceVm Compile Menu
 *
 */
#define CONFIG_HAVE_FB_SDL_SUPPORT 1
#define CONFIG_FB_SDL_HEIGHT 480
#define CONFIG_FB_SDL_WIDTH 600
